#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
/*Comentario
Utilizar las 2 estructuras del ejercicio d, pero ahora pedir los datos para N 
alumnos, y calcular cual de todos tiene el mejor promedio, e imprimir sus datos.
Elaborado por: leyder Londo�o Mejia*/
struct prom{
	float nota1;
	float nota2;
	float nota3;
};

struct alumno{
	char nombre[20];
	char sexo[20];
	int edad;
	struct promedio prom;
}alumnos[100];

void estudiantes(alumno v[],int longt);

int main()
{
	alumno v[100];
	int longt;
	estudiantes(v,longt);
	return 0;
}

void estudiantes(alumno v[],int longt){
	printf("\nPrograma que imprime el mayor y menor promedio de un listado de \nvarios estudiantes ingresados por el usuario\n");
	printf("-----------------------------------------------");
	int num,posMayor,posMenor;
	float pmayor=0.0;
	float pmenor=9.0;
	printf("\nIngrese cantidad de alumnos\n");
	scanf("%d",&num);
	printf("Ingrese datos del alumnos\n");
	for(int i=0;i<num;i++){
		printf("%i.Nombre: ",i+1);
		fflush stdin;
		fgets(estudiante[i].nombre,20,stdin);
		printf("\n%i.Edad: ",i+1);
		scanf("%d",&estudiante[i].edad);
		printf("\n%i.Sexo: ",i+1);
		fflush stdin;
		fgets(estudiante[i].sexo,20,stdin);
		printf("\n%i.Nota 1. ",i+1);
		scanf("%f",&estudiante[i].notas.nota1);
		printf("\n%i.Nota 2. ",i+1);
		scanf("%f",&estudiante[i].notas.nota2);
		printf("\n%i.Nota 3. ",i+1);
		scanf("%f",&estudiante[i].notas.nota3);	
		estudiante[i].totalProm=(estudiante[i].notas.nota1+estudiante[i].notas.nota2+estudiante[i].notas.nota3)/3;
		if(estudiante[i].totalProm>pmayor){
			pmayor=estudiante[i].totalProm;
			posMayor=i;
		}
		if(estudiante[i].totalProm<pmenor){
			pmenor=estudiante[i].totalProm;
			posMenor=i;
		}
	}
	printf("\n<<<<<Mostrando Datos>>>>>>>\n");
	printf("\nMayor Promedio\n");
	printf("Nombre:%s Edad:%d Sexo:%s Promedio:%.1f ",estudiante[posMayor].nombre,estudiante[posMayor].edad,estudiante[posMayor].sexo,estudiante[posMayor].totalProm);
	
	printf("\n\nMenor Promedio\n");
	printf("Nombre:%s Edad:%d Sexo:%s Promedio:%.1f ",estudiante[posMenor].nombre,estudiante[posMenor].edad,estudiante[posMenor].sexo,estudiante[posMenor].totalProm);
}

