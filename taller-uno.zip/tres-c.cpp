#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
/*Comentario
Programa:Crear un arreglo de dimension 4x4 y pedirle al usuario,
que ingrese 4 numeros. En la primera Columna mostrar los numeros ingresados,
por el usuario, en la segunda columna el numero elevado al cuadrado, en la 
tercera columna el numero elevado al cubo y en la cuarta e�l numero elevado a
la cuarta. Imprimir en pantalla el resultado del arreglo.
Elaborado por: Leyder Londo�o Mejia,Fernando Lopez Mejia*/
int main() {
	int matriz[4][4];
	int i,j;
	int num;
	for(i=0;i<4;i++){
	printf(" Digite un numero matriz[%][%i]: \n ",i+1,j+1);	
		scanf("%i",&num);
		for(j=0;j<4;j++){
			if(j==0){
				matriz[i][j]=num;
			}
			if(j==1){
				matriz[i][j]=pow(num,2);
			}
			if(j==2){
				matriz[i][j]=pow(num,3);
			}
			if(j==3){
				matriz[i][j]=pow(num,4);
			}
		}
		printf("\n");
	}
	
	for(i=0;i<4;i++){
		for(j=0;j<4;j++){
			
			printf("%i ",matriz[i][j]);
		}
		printf("\n\n");
	}
	
	return 0;
}


