#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
/*Comentario
Programa:Solucionar el numero fibonacci
Elaborado por: Leyder Londo�o Mejia,Fernando Lopez Mejia*/
int main() {
	int num,x=0,y=1,z=1;
	printf("Ingrese el numero de elementos \n");
	scanf("%i",&num);
	for(int i=1;i<num;i++){
		z=x+y;
		printf("%i",z);
		x=y;
		y=z;
	}
	return 0;
}

