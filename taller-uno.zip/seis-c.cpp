#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
/*Comentario
Hacer 2 estructuras una llamada promedio que tendra los siguientes miembros: 
nota1,nota2,nota3; y otro llamada alumno que tendra los siguientes miembros:
nombre, sexo, edad; hacer que la estructura promedio este anidada en la estructura
alumno, luego pedir todos los datos para un alumno, luego calcular su promedio, y por
ultimo imprimir todos sus datos incluidos el promedio.
Elaborado por: Leyder Londo�o Mejia,Fernando Lopez Mejia*/
struct promedio{
	float nota1;
	float nota2;
	float nota3;
};
struct alumno{
	char nombre[20];
	char sexo[20];
	int edad;
	struct promedio prom;
}alumnos;

void estudiante(alumno v[]);

int main()
{
	alumno v[100];
	estudiante(v);
	return 0;
}

void estudiante(alumno v[]){
	int i;
	float promedio=0;	
	printf("Nombre \n ");
	fflush(stdin);
	fgets(alumnos.nombre,20,stdin);
	printf("Sexo \n ");
	fgets(alumnos.sexo,20,stdin);
	printf("Edad \n ");
	scanf("%i",&alumnos.edad);
	printf(" Ingrese las 3 notas \n");
	scanf("%f %f %f",&alumnos.prom.nota1,&alumnos.prom.nota2,&alumnos.prom.nota3);	
	promedio = (alumnos.prom.nota1+alumnos.prom.nota2+alumnos.prom.nota3)/3;	
	printf("\n\n ------ *Datos del Alumno* -------\n");
	printf("\n Nombre %s",alumnos.nombre);
	printf("\n Sexo %s",alumnos.sexo);
	printf("\n Edad %i",alumnos.edad);
	printf("\n Promedio %.2f \n",promedio);		
}

