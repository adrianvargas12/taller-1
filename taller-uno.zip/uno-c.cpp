#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
/*Comentario
Programa:Sumar los numeros pares del 1 al 50
Elaborado por: Leyder Londo�o Mejia,Fernando Lopez Mejia*/
int main() {
	printf("\nSumatoria de los numeros Impares del 1 al 50.\n");
	printf("-----------------------------------------------");
	int i=1;
	int sumaImpares=0;
	while(i<=50){		
		sumaImpares=sumaImpares+i;
		i+=2;
	}	
	printf("\nResultado==> %d\n",sumaImpares);
	return 0;
}


